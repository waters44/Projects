/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg255project;

/**
 *
 * @author lucywaters
 */
import java.awt.*;

public abstract class Player {
    public char symbol;
    public Color color;

    public abstract void startTurn();
}


