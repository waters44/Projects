/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pkg255project;

/**
 *
 * @author lucywaters
 */

import java.awt.*;

public class ComputerPlayer extends Player {
    public ComputerPlayer() {
        symbol = 'O';
        color = Color.CYAN; // Corrected syntax for setting color
    }

    @Override
    public void startTurn() {
        // Implementation for computer player's turn if needed
    }
}

